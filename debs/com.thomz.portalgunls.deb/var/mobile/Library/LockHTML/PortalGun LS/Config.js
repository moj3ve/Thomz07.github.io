var Clock = "12h"; // choose between "12h" or "24h"

