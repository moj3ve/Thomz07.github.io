var Clock = false; // 12h Clock
var Text = "and the image on the right bottom"; // Add your custom text
var Color = "cyan"; // Change the color of the widget just by tapping : red for red,blue for blue,...                                  (You can also use HTML color codes for more specific colors)
var Image = "profile.jpg"; // Place an image via Filza to /var/mobile/Library/SBHTML/Linedget/img/ and put your image here (You can find your gallery folder at /var/mobile/Media/DCIM/101APPLE) and change the text to your image name (with the extension)
