var Width = "90"; // the width is using % of the screen
var Height = "200"; // the height is using pixels
var Gradient = true; // write the two colors onBackground section like this = color1, color2
var GradientOrientation = "46deg"; // choose the orientation of your gradient
var Background = "grey, black"; // write transparent if you don’t want a background
var BorderWidth = "0"; // the width is in pixels
var BorderColor = "#ff3000"; 
var BorderRadius = "5"; // if you have the label option activated, it’ll look weird over 40
var Opacity = "1"; 
var Shadow = true; 
var Label = true; // add a label. WARNING : the label background will look weird if u set a border so if you want a border without label background, set the label background opacity to 0, if u want a background to your label, set the border to 0
var LabelText = "Hello guys"; // write something
var LabelFontSize = "20"; 
var LabelColor = "black"; 
var BackgroundLabelGradient = false; // work exactly like the background gradient (the orientation will be the same as the one for the background)
var BackgroundLabelColor = "#d9d9d9"; 
var BackgroundLabelOpacity = "1"; 
var LabelPosition = "center"; // choose between left center and right
