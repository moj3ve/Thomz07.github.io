var Width = "90"; // the width is using % of the screen
var Height = "200"; // the height is using pixels
var Background = "white"; // write transparent if you don’t want a background
var Border = "1px solid grey"; // width, style, color
var BorderRadius = "30"; 
var Opacity = "1"; 
var Shadow = false; 
